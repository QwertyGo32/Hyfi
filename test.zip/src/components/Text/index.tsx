import React from 'react'

export default function Text() {
  return <p>Hello world</p>
}
